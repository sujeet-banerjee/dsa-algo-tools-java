package sujeet.classes.learn.poly;

class Dog extends Animal {
    @Override
    public int speak() {
        System.out.println("The Dog BARKED!!! MY AGE IS : " + this.getAge());
        return getAge();
    }
}